# Omni CLI

The awesome Omni CLI.
